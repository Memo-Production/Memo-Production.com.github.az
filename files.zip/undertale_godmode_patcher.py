#!/usr/bin/env python3
"""
UNDERTALE GOD MODE PATCHER
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
A GUI tool to modify Undertale save files with custom stats.

Features:
  • Modify HP, ATK, DEF, GOLD, LV, EXP
  • One-click God Mode preset
  • Auto-detect save location
  • Auto-backup before patching
  • Dark retro aesthetic (MemoProduction style)

Usage:
  1. Start Undertale, create/load game, SAVE
  2. Quit Undertale
  3. python undertale_godmode_patcher.py
  4. Select stats, click "SAVE FAYLINA TƏTBİQ ET"
  5. Load game in Undertale

GitHub: https://github.com/YourUsername/undertale-godmode-patcher
License: MIT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"""

import tkinter as tk
from tkinter import filedialog, messagebox
import os
import shutil

# ─── MemoProduction Rənglər ───────────────────────────────
BG        = "#0a0a0f"
PANEL     = "#12121a"
BORDER    = "#1e1e2e"
ACCENT    = "#c800ff"
ACCENT2   = "#ff00aa"
TEXT      = "#e0e0f0"
TEXT_DIM  = "#555577"
GREEN     = "#00ff88"
RED       = "#ff3355"
GOLD      = "#ffd700"

# ─── Undertale Save Faylı Format ─────────────────────────
# Her sətir bir dəyərdir, sıra belədir:
SAVE_FIELDS = [
    "player_name",      # 0  - oyunçu adı (mətn)
    "hp",               # 1  - cari HP
    "max_hp",           # 2  - maksimum HP
    "atk",              # 3  - hücum
    "df",               # 4  - müdafiə
    "gold",             # 5  - qızıl
    "room",             # 6  - otaq nömrəsi
    "death_count",      # 7  - ölüm sayı
    "kills",            # 8  - öldürmə sayı
    "love",             # 9  - LV (LOVE level)
    "exp",              # 10 - EXP
    "next_exp",         # 11 - növbəti LV üçün EXP
    "plot",             # 12 - süjet sayacı
    "mystery1",         # 13
    "mystery2",         # 14
    "time",             # 15 - oyun vaxtı
    "room2",            # 16
    "mystery3",         # 17
    "mystery4",         # 18
    "mystery5",         # 19
]

GOD_VALUES = {
    "hp":       9999,
    "max_hp":   9999,
    "atk":      9999,
    "df":       9999,
    "gold":     9999,
    "love":     20,
    "exp":      99999,
    "kills":    0,      # Pacifist üçün 0 saxla (istəsə dəyişər)
    "death_count": 0,
}

class UndertalePatcher:
    def __init__(self, root):
        self.root = root
        self.root.title("UNDERTALE — GOD MODE PATCHER")
        self.root.configure(bg=BG)
        self.root.resizable(False, False)
        self.root.geometry("520x640")

        self.save_path = tk.StringVar()
        self.status_var = tk.StringVar(value="")
        self.preview_lines = []

        # Stat dəyişənləri
        self.stat_vars = {}
        for field in ["hp", "max_hp", "atk", "df", "gold", "love", "exp", "death_count", "kills"]:
            self.stat_vars[field] = tk.StringVar(value=str(GOD_VALUES.get(field, "")))

        self._build_ui()
        self._auto_detect_save()

    def _build_ui(self):
        root = self.root

        # ── Başlıq ──────────────────────────────────────────
        header = tk.Frame(root, bg=BG)
        header.pack(fill="x", padx=20, pady=(18, 0))

        tk.Label(header, text="⬡  UNDERTALE", font=("Courier New", 11, "bold"),
                 fg=TEXT_DIM, bg=BG).pack(anchor="w")
        tk.Label(header, text="GOD MODE PATCHER",
                 font=("Courier New", 22, "bold"), fg=ACCENT, bg=BG).pack(anchor="w")

        tk.Label(header, text="by MemoProduction",
                 font=("Courier New", 9), fg=TEXT_DIM, bg=BG).pack(anchor="w")

        tk.Frame(root, bg=ACCENT, height=1).pack(fill="x", padx=20, pady=(10, 0))

        # ── Save Faylı Seçimi ────────────────────────────────
        path_frame = tk.Frame(root, bg=PANEL, bd=0, relief="flat")
        path_frame.pack(fill="x", padx=20, pady=12)

        tk.Label(path_frame, text="SAVE FAYLI", font=("Courier New", 8, "bold"),
                 fg=ACCENT2, bg=PANEL).pack(anchor="w", padx=10, pady=(8,2))

        row = tk.Frame(path_frame, bg=PANEL)
        row.pack(fill="x", padx=10, pady=(0,8))

        entry = tk.Entry(row, textvariable=self.save_path,
                         bg=BORDER, fg=TEXT, insertbackground=ACCENT,
                         font=("Courier New", 9), bd=0, relief="flat",
                         width=38)
        entry.pack(side="left", ipady=6, padx=(0,6))

        tk.Button(row, text="AXTAR", command=self._browse,
                  bg=ACCENT, fg="white", font=("Courier New", 8, "bold"),
                  bd=0, relief="flat", cursor="hand2",
                  activebackground=ACCENT2, activeforeground="white",
                  padx=10, pady=4).pack(side="left")

        # ── Stat Paneli ──────────────────────────────────────
        tk.Label(root, text="STAT DƏYƏRLƏRİ", font=("Courier New", 9, "bold"),
                 fg=ACCENT2, bg=BG).pack(anchor="w", padx=20, pady=(4,4))

        stat_panel = tk.Frame(root, bg=PANEL)
        stat_panel.pack(fill="x", padx=20)

        labels = {
            "hp":         ("❤  HP (cari)",     GREEN),
            "max_hp":     ("❤  MAX HP",         GREEN),
            "atk":        ("⚔  ATK",           "#ff8844"),
            "df":         ("🛡  DEF",           "#4488ff"),
            "gold":       ("★  GOLD",          GOLD),
            "love":       ("☠  LV (1-20)",     RED),
            "exp":        ("✦  EXP",           TEXT),
            "death_count":("☠  Ölüm sayı",     TEXT_DIM),
            "kills":      ("☠  Kill sayı",      TEXT_DIM),
        }

        fields_left  = ["hp", "max_hp", "atk", "df", "gold"]
        fields_right = ["love", "exp", "death_count", "kills"]

        # İki sütun
        cols = tk.Frame(stat_panel, bg=PANEL)
        cols.pack(fill="x", padx=10, pady=10)

        def make_col(parent, fields):
            col = tk.Frame(parent, bg=PANEL)
            col.pack(side="left", fill="both", expand=True, padx=5)
            for f in fields:
                lbl_text, color = labels[f]
                row = tk.Frame(col, bg=PANEL)
                row.pack(fill="x", pady=3)
                tk.Label(row, text=lbl_text, font=("Courier New", 8),
                         fg=color, bg=PANEL, width=16, anchor="w").pack(side="left")
                ent = tk.Entry(row, textvariable=self.stat_vars[f],
                               bg=BORDER, fg=color, insertbackground=ACCENT,
                               font=("Courier New", 10, "bold"), bd=0,
                               width=8, justify="center")
                ent.pack(side="left", ipady=4)
            return col

        make_col(cols, fields_left)
        tk.Frame(cols, bg=BORDER, width=1).pack(side="left", fill="y", padx=5)
        make_col(cols, fields_right)

        # God Mode tez düymələri
        btn_row = tk.Frame(root, bg=BG)
        btn_row.pack(pady=(8,0))

        tk.Button(btn_row, text="☠ MAX GOD MODE", command=self._set_god,
                  bg=ACCENT, fg="white", font=("Courier New", 9, "bold"),
                  bd=0, relief="flat", cursor="hand2",
                  activebackground=ACCENT2, padx=14, pady=5).pack(side="left", padx=4)

        tk.Button(btn_row, text="✦ RESET NORMAL", command=self._set_normal,
                  bg=BORDER, fg=TEXT, font=("Courier New", 9, "bold"),
                  bd=0, relief="flat", cursor="hand2",
                  activebackground=PANEL, padx=14, pady=5).pack(side="left", padx=4)

        tk.Frame(root, bg=ACCENT, height=1).pack(fill="x", padx=20, pady=12)

        # ── Tətbiq Et Düyməsi ────────────────────────────────
        tk.Button(root, text="▶  SAVE FAYLINA TƏTBİQ ET",
                  command=self._patch,
                  bg=GREEN, fg=BG, font=("Courier New", 12, "bold"),
                  bd=0, relief="flat", cursor="hand2",
                  activebackground="#00cc66", activeforeground=BG,
                  pady=12).pack(fill="x", padx=20)

        # ── Status ───────────────────────────────────────────
        self.status_lbl = tk.Label(root, textvariable=self.status_var,
                                   font=("Courier New", 9), fg=TEXT_DIM, bg=BG,
                                   wraplength=480)
        self.status_lbl.pack(pady=(8,0), padx=20)

        # ── Footer ───────────────────────────────────────────
        tk.Label(root, text="© 2024 MemoProduction  |  Backup avtomatik yaradılır",
                 font=("Courier New", 7), fg=TEXT_DIM, bg=BG).pack(side="bottom", pady=8)

    # ─── Funksiyalar ─────────────────────────────────────────

    def _auto_detect_save(self):
        """Windows-da avtomatik save faylını tap"""
        local = os.environ.get("LOCALAPPDATA", "")
        candidates = [
            os.path.join(local, "UNDERTALE", "file0"),
            os.path.join(local, "UNDERTALE", "undertale_save"),
            os.path.join(os.path.expanduser("~"), ".config", "UNDERTALE", "file0"),
        ]
        for path in candidates:
            if os.path.exists(path):
                self.save_path.set(path)
                self._set_status(f"✓ Save tapıldı: {path}", GREEN)
                return
        self._set_status("⚠  Save faylı avtomatik tapılmadı. Manual seçin.", GOLD)

    def _browse(self):
        path = filedialog.askopenfilename(
            title="Undertale Save Faylını Seç",
            filetypes=[("Save faylları", "file0 file1 file2 *.sav"), ("Hamısı", "*.*")],
            initialdir=os.path.join(os.environ.get("LOCALAPPDATA", ""), "UNDERTALE")
        )
        if path:
            self.save_path.set(path)
            self._set_status(f"✓ Seçildi: {path}", GREEN)

    def _set_god(self):
        defaults = {"hp":9999,"max_hp":9999,"atk":9999,"df":9999,
                    "gold":9999,"love":20,"exp":99999,"death_count":0,"kills":0}
        for k, v in defaults.items():
            self.stat_vars[k].set(str(v))
        self._set_status("☠ Max God Mode dəyərləri seçildi.", ACCENT)

    def _set_normal(self):
        defaults = {"hp":20,"max_hp":20,"atk":10,"df":10,
                    "gold":0,"love":1,"exp":0,"death_count":0,"kills":0}
        for k, v in defaults.items():
            self.stat_vars[k].set(str(v))
        self._set_status("✦ Normal başlanğıc dəyərləri seçildi.", TEXT)

    def _patch(self):
        path = self.save_path.get().strip()
        if not path or not os.path.exists(path):
            self._set_status("✗ Save faylı tapılmadı! Əvvəlcə oyunu oynayıb save edin.", RED)
            return

        # Backup yarat
        backup = path + ".backup"
        shutil.copy2(path, backup)

        try:
            with open(path, "r", encoding="utf-8") as f:
                lines = f.read().splitlines()

            # Dəyərləri al
            new_vals = {}
            for field, var in self.stat_vars.items():
                try:
                    new_vals[field] = int(var.get())
                except ValueError:
                    self._set_status(f"✗ '{field}' üçün yanlış dəyər!", RED)
                    return

            # Field index mapping
            idx_map = {
                "hp":          1,
                "max_hp":      2,
                "atk":         3,
                "df":          4,
                "gold":        5,
                "death_count": 7,
                "kills":       8,
                "love":        9,
                "exp":         10,
            }

            # Xəttləri yenilə
            for field, idx in idx_map.items():
                if idx < len(lines):
                    lines[idx] = str(new_vals[field])

            with open(path, "w", encoding="utf-8") as f:
                f.write("\n".join(lines))

            msg = (f"✓ GOD MODE TƏTBİQ EDİLDİ!\n"
                   f"HP: {new_vals['max_hp']}  ATK: {new_vals['atk']}  "
                   f"DEF: {new_vals['df']}  GOLD: {new_vals['gold']}  LV: {new_vals['love']}\n"
                   f"Backup: {backup}")
            self._set_status(msg, GREEN)
            messagebox.showinfo("Uğurlu!", "God Mode aktivləşdi!\nOyunu açın və save yükləyin.")

        except Exception as e:
            self._set_status(f"✗ Xəta: {e}", RED)
            shutil.copy2(backup, path)

    def _set_status(self, msg, color=TEXT):
        self.status_var.set(msg)
        self.status_lbl.configure(fg=color)


if __name__ == "__main__":
    root = tk.Tk()
    app = UndertalePatcher(root)
    root.mainloop()
